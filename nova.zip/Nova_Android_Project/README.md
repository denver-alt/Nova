# Nova Offline AI for Android

A standalone Android Studio project for Nova. It embeds the official `llama.cpp` Android inference library in the app process. It does **not** require PocketPal, Ollama, a localhost server, or a cloud AI service for chat.

## Target device

- OnePlus 9, Android 14, ARM64
- Kotlin + Jetpack Compose
- Room local database for chat history, imported knowledge, study tasks, and evidence records
- WorkManager study queue
- GGUF models stored in Nova's private internal app storage (`files/models`)
- Official `ggml-org/llama.cpp` Android binding, built from source for `arm64-v8a`

## What is included

- Standalone offline chat using a locally loaded GGUF model
- Local conversation history, with recent turns included in the next prompt
- Import GGUF files from device storage
- Optional Hugging Face public repository search and GGUF download
- TXT/Markdown knowledge import and local keyword retrieval
- “Go to school on…” study queue; generated reports are explicitly classified as unverified AI hypotheses
- Evidence vault with provenance and confidence labels
- JSON backup export
- A process-wide inference lock to prevent the single native engine from loading two models at once

## Prepare the native engine (required once)

The native library is built from the upstream source tree, so the complete repository must remain under `vendor/llama.cpp`. Do not move the Android binding module out of that tree: its CMake file uses relative paths to the llama.cpp root.

**Windows:** run `prepare.bat`.

**macOS/Linux:** run `chmod +x prepare.sh && ./prepare.sh`.

The script clones the public `ggml-org/llama.cpp` repository (no GitHub account is required) and adjusts only the Android library module's Gradle plugin/dependency declarations so it can be included by this project. It limits the native build to `arm64-v8a` for the OnePlus 9.

## Android Studio requirements

Install these through Android Studio SDK Manager:

- Android SDK Platform 36
- Android NDK `29.0.13113456`
- CMake `3.31.6`
- JDK 17 (Android Studio's bundled JBR is suitable)

Then open the `Nova_Android_Project` folder, allow Gradle sync, and build the `app` debug APK. The first native build can take a while and requires several GB of temporary disk space. This environment does not contain Android SDK/NDK or Gradle, so this ZIP has **not** been compiled or device-tested here.

## First run

1. Open **Models**.
2. Import a `.gguf` file from device storage, or optionally search/download a public GGUF from Hugging Face.
3. Tap **Load** beside the model.
4. Open **Chat** and send a message.

For an 8 GB OnePlus 9, start with a 2B–4B model in a 4-bit quantization and a modest context length. Model size on disk is not the same as peak RAM use; Android, the context/KV cache, and native buffers need memory too. RAM expansion is not equivalent to physical RAM.

## Offline and network behavior

- **Chat, model loading, chat history, imported library, study reports, and evidence vault work locally.**
- The Android `INTERNET` permission is present only for the optional Hugging Face search/download screen. If you already imported a model, you can use Nova with Wi-Fi and mobile data disabled.
- No cloud API key or PocketPal server is used.
- The project does not send chat content to Hugging Face. Hugging Face is contacted only when the user explicitly searches or downloads a model.

## Learning limits and safeguards

“Go to school on…” searches imported local TXT/Markdown material, builds a research prompt, runs the local model, and saves the report separately as `AI_GENERATED_HYPOTHESIS`.

This is retrieval and synthesis, not autonomous model training:

- It can connect supplied material with the model's pretrained knowledge.
- It cannot discover new external facts while offline unless new material is imported.
- It does not modify model weights or fine-tune the GGUF.
- Generated conclusions are not automatically verified facts.
- Android may defer WorkManager jobs because of battery and background-execution rules.

## Known omissions in this build

- Backup restore UI (JSON export is included; restore is a next feature)
- PDF/DOCX/image/audio ingestion
- Gated Hugging Face model authentication
- Automatic external fact-checking
- Fine-tuning or continual model-weight training
- Guaranteed uninterrupted background learning
- GPU/NPU acceleration. This build uses the official Android llama.cpp binding with ARM CPU optimizations; it does not claim Hexagon NPU support.

Models and the database are in private app storage. Android normally deletes this data when the app is uninstalled. Export the backup and keep a separate copy of model files before uninstalling.

## Upstream references

- llama.cpp Android guide: https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
- llama.cpp Android binding: https://github.com/ggml-org/llama.cpp/tree/master/examples/llama.android
- Hugging Face Hub API: https://huggingface.co/docs/hub/api
- Android WorkManager: https://developer.android.com/develop/background-work/background-tasks/persistent

## Optional free cloud build (GitHub Actions)

The project includes `.github/workflows/android-apk.yml`. If you place this project in a GitHub repository, open **Actions → Build Nova Android APK → Run workflow**. The workflow installs the required Android SDK/NDK/CMake, prepares the official llama.cpp binding, builds the debug APK, and uploads `Nova-debug-apk` as an artifact. This is optional; it requires a GitHub account and repository. The APK is not produced until that workflow completes successfully.


## Build status (important)

This is a source project, not a prebuilt or device-tested APK. The cloud workflow is configured to compile a debug APK, but a successful build has not yet been observed. It uses Android Gradle Plugin 8.10.1 because the project compiles against Android API 36; AGP 8.9 only supports API 35. The native llama.cpp Android binding is fetched from its upstream repository by `prepare.sh` / `prepare.ps1` at build time.
