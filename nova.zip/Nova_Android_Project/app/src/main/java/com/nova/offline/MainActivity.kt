package com.nova.offline

import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.work.*
import com.nova.offline.ai.LocalModel
import com.nova.offline.data.*
import com.nova.offline.hf.*
import com.nova.offline.learning.StudyWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private val db by lazy { NovaDatabase.get(this) }
    private val hf by lazy { HuggingFaceClient() }
    private var loadedModel: LocalModel? = null
    private var activeChatJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaUI() }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable private fun NovaUI() {
        var tab by remember { mutableStateOf("Chat") }
        MaterialTheme {
            Scaffold(
                topBar={ TopAppBar(title={Text("NOVA  •  Offline AI")}, actions={Text("LOCAL",Modifier.padding(end=16.dp))}) },
                bottomBar={
                    NavigationBar {
                        listOf("Chat","School","Library","Models","Vault").forEach { t ->
                            NavigationBarItem(selected=tab==t,onClick={tab=t},icon={Text(t.take(1))},label={Text(t)})
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when(tab) {
                        "Chat" -> Chat()
                        "School" -> School()
                        "Library" -> Library()
                        "Models" -> Models()
                        else -> Vault()
                    }
                }
            }
        }
    }

    @Composable private fun Chat() {
        val scope=rememberCoroutineScope()
        var input by remember { mutableStateOf("") }
        var list by remember { mutableStateOf(emptyList<ChatMessage>()) }
        var status by remember { mutableStateOf("Load a GGUF model in Models to begin.") }
        var busy by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { list=withContext(Dispatchers.IO){db.dao().messages()} }
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Text(status,style=MaterialTheme.typography.bodySmall)
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(list) { m -> Card(Modifier.fillMaxWidth().padding(vertical=3.dp)) {
                    Column(Modifier.padding(10.dp)) { Text(m.role.uppercase(),style=MaterialTheme.typography.labelSmall); Text(m.text) }
                } }
            }
            OutlinedTextField(input,{input=it},Modifier.fillMaxWidth(),label={Text("Message Nova")},enabled=!busy)
            Button(
                onClick={
                    val q=input.trim(); input=""; busy=true
                    activeChatJob = scope.launch {
                        try {
                            withContext(Dispatchers.IO){db.dao().addMessage(ChatMessage(role="user",text=q))}
                            val refs=withContext(Dispatchers.IO){db.dao().searchKnowledge(q,5)}
                            val history=withContext(Dispatchers.IO){db.dao().messages().dropLast(1).takeLast(10)}
                            val transcript=history.joinToString("\n") { "${it.role.uppercase()}: ${it.text.take(1800)}" }
                            val extra=refs.joinToString("\n\n"){ "LOCAL SOURCE ${it.title}:\n${it.content.take(2200)}" }
                            val model=ensureLoaded()
                            val prompt=buildString {
                                if (transcript.isNotBlank()) append("RECENT CONVERSATION:\n$transcript\n\n")
                                if (extra.isNotBlank()) append("RELEVANT LOCAL SOURCES (cite titles; distinguish source text from inference):\n$extra\n\n")
                                append("USER: $q")
                            }
                            val answer=withContext(Dispatchers.IO){model.generate(prompt,700)}
                            withContext(Dispatchers.IO){db.dao().addMessage(ChatMessage(role="assistant",text=answer))}
                            list=withContext(Dispatchers.IO){db.dao().messages()}; status="Local response complete."
                        } catch(t:Throwable) { status="Chat error: ${t.message}"; list=withContext(Dispatchers.IO){db.dao().messages()} }
                        busy=false
                    }
                },enabled=!busy && input.isNotBlank(),modifier=Modifier.fillMaxWidth()
            ){Text(if(busy)"Thinking…" else "Send")}
        }
    }

    private suspend fun ensureLoaded(): LocalModel = withContext(Dispatchers.IO) {
        val path=getSharedPreferences("nova",MODE_PRIVATE).getString("active_model_path",null) ?: error("No model loaded. Open Models.")
        if(loadedModel==null) {
            val candidate = LocalModel(applicationContext)
            try {
                candidate.load(File(path))
                candidate.system("You are Nova, a careful offline AI. Be accurate, distinguish facts from hypotheses, and cite local sources.")
                loadedModel = candidate
            } catch (t: Throwable) {
                runCatching { candidate.unload() }
                throw t
            }
        }
        loadedModel!!
    }

    @Composable private fun School() {
        val scope=rememberCoroutineScope()
        var topic by remember { mutableStateOf("") }
        var tasks by remember { mutableStateOf(emptyList<StudyTask>()) }
        var note by remember { mutableStateOf("Say what Nova should study. It searches local imported knowledge and saves its analysis separately as an unverified hypothesis.") }
        LaunchedEffect(Unit){tasks=withContext(Dispatchers.IO){db.dao().tasks()}}
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("GO TO SCHOOL ON…",style=MaterialTheme.typography.headlineSmall)
            Text(note,style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(vertical=8.dp))
            OutlinedTextField(topic,{topic=it},Modifier.fillMaxWidth(),label={Text("Subject")})
            Button(onClick={
                val t=topic.trim()
                if(t.isNotEmpty()) scope.launch {
                    val id=withContext(Dispatchers.IO){db.dao().addTask(StudyTask(topic=t))}
                    val req=OneTimeWorkRequestBuilder<StudyWorker>().setInputData(workDataOf("task_id" to id))
                        .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build()).build()
                    WorkManager.getInstance(this@MainActivity).enqueue(req)
                    tasks=withContext(Dispatchers.IO){db.dao().tasks()}; topic=""
                    note="Task queued. Android may defer background execution. A model must be downloaded and loaded first."
                }
            },modifier=Modifier.fillMaxWidth()){Text("Start studying")}
            LazyColumn { items(tasks){x -> Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){
                Column(Modifier.padding(10.dp)){Text(x.topic,style=MaterialTheme.typography.titleMedium);Text(x.status,style=MaterialTheme.typography.labelSmall);if(x.report.isNotBlank())Text(x.report.take(900))}
            }}}
        }
    }

    @Composable private fun Library() {
        val scope=rememberCoroutineScope()
        var docs by remember { mutableStateOf(emptyList<KnowledgeItem>()) }
        var status by remember { mutableStateOf("Import TXT or Markdown files to build Nova's offline library.") }
        val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
            if(uri!=null) scope.launch {
                try {
                    val body=withContext(Dispatchers.IO){contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()} ?: error("Could not open file")}
                    withContext(Dispatchers.IO){db.dao().addKnowledge(KnowledgeItem(title=uri.lastPathSegment?.substringAfterLast('/') ?: "Imported text",source=uri.toString(),content=body))}
                    docs=withContext(Dispatchers.IO){db.dao().knowledge()}; status="Imported ${body.length} characters."
                } catch(t:Throwable){status="Import failed: ${t.message}"}
            }
        }
        LaunchedEffect(Unit){docs=withContext(Dispatchers.IO){db.dao().knowledge()}}
        Column(Modifier.fillMaxSize().padding(16.dp)){
            Text("KNOWLEDGE LIBRARY",style=MaterialTheme.typography.headlineSmall)
            Text(status,style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(vertical=8.dp))
            Button(onClick={picker.launch(arrayOf("text/plain","text/markdown","text/*"))},modifier=Modifier.fillMaxWidth()){Text("Import TXT / Markdown")}
            Text("${docs.size} source documents",modifier=Modifier.padding(vertical=8.dp))
            LazyColumn{items(docs){d->Card(Modifier.fillMaxWidth().padding(vertical=3.dp)){Column(Modifier.padding(10.dp)){Text(d.title);Text("${d.content.length} characters",style=MaterialTheme.typography.bodySmall)}}}}
        }
    }

    @Composable private fun Models() {
        val scope=rememberCoroutineScope()
        var query by remember{mutableStateOf("Qwen3 4B GGUF")}
        var models by remember{mutableStateOf(emptyList<HfModel>())}
        var files by remember{mutableStateOf(emptyList<HfFile>())}
        var repo by remember{mutableStateOf("")}
        var local by remember{mutableStateOf(emptyList<File>())}
        var status by remember{mutableStateOf("Search Hugging Face for public GGUF repositories. Check file size and license.") }
        var active by remember{mutableStateOf(getSharedPreferences("nova",MODE_PRIVATE).getString("active_model_path",null) ?: "None")}
        val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) scope.launch {
                try {
                    val displayName = withContext(Dispatchers.IO) {
                        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                            if (c.moveToFirst()) c.getString(0) else null
                        } ?: uri.lastPathSegment?.substringAfterLast('/') ?: "imported-model.gguf"
                    }
                    require(displayName.endsWith(".gguf", true)) { "Choose a .gguf model file." }
                    val dir = File(filesDir, "models").apply { mkdirs() }
                    val target = File(dir, displayName.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    val partial = File(dir, target.name + ".part")
                    withContext(Dispatchers.IO) {
                        contentResolver.openInputStream(uri)?.use { input -> partial.outputStream().use { output -> input.copyTo(output) } }
                            ?: error("Could not open selected model file.")
                        if (target.exists() && !target.delete()) error("Could not replace the existing model file.")
                        if (!partial.renameTo(target)) error("Could not finalize imported model file.")
                    }
                    local = dir.listFiles()?.filter { it.isFile && it.extension.equals("gguf", true) } ?: emptyList()
                    status = "Imported ${target.name}. Select Load to start it."
                } catch (t: Throwable) { status = "Import failed: ${t.message}" }
            }
        }
        LaunchedEffect(Unit){local=File(filesDir,"models").listFiles()?.filter{it.isFile && it.extension.equals("gguf",true)} ?: emptyList()}
        Column(Modifier.fillMaxSize().padding(12.dp)){
            Text("MODEL MANAGER",style=MaterialTheme.typography.headlineSmall)
            Text("Active: ${active.substringAfterLast('/')}",style=MaterialTheme.typography.bodySmall)
            Button(onClick={importPicker.launch(arrayOf("application/octet-stream", "application/x-gguf", "*/*"))},modifier=Modifier.fillMaxWidth()){Text("Import GGUF from device")}
            OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("Hugging Face search")})
            Button(onClick={scope.launch {
                status="Searching…"
                try{models=withContext(Dispatchers.IO){hf.search(query)};status="${models.size} repositories found"}
                catch(t:Throwable){status="Search error: ${t.message}"}
            }},modifier=Modifier.fillMaxWidth()){Text("Search")}
            Text(status,style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(vertical=6.dp))
            LazyColumn(Modifier.weight(1f)){
                items(models){m->Card(Modifier.fillMaxWidth().padding(vertical=3.dp)){Column(Modifier.padding(8.dp)){
                    Text(m.id,style=MaterialTheme.typography.titleSmall);Text("${m.downloads} downloads • ${m.likes} likes",style=MaterialTheme.typography.bodySmall)
                    TextButton(onClick={repo=m.id;scope.launch{try{files=withContext(Dispatchers.IO){hf.files(m.id)};status="${files.size} GGUF files in ${m.id}"}catch(t:Throwable){status=t.message ?: "Error"}}}){Text("List GGUF files")}
                }}}
                items(files){f->Card(Modifier.fillMaxWidth().padding(vertical=2.dp)){Row(Modifier.padding(8.dp),horizontalArrangement=Arrangement.SpaceBetween){
                    Text(f.name,Modifier.weight(1f),style=MaterialTheme.typography.bodySmall)
                    TextButton(onClick={scope.launch{
                        status="Downloading ${f.name}…"
                        try{val out=File(File(filesDir,"models"),f.name.substringAfterLast('/'))
                            withContext(Dispatchers.IO){hf.download(repo,f.name,out){_,_->}}
                            local=File(filesDir,"models").listFiles()?.filter{it.extension.equals("gguf",true)} ?: emptyList()
                            status="Downloaded ${out.name}"
                        }catch(t:Throwable){status="Download failed: ${t.message}"}
                    }}){Text("Download")}
                }}}
            }
            Text("Downloaded models",style=MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.heightIn(max=150.dp)){items(local){f->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                Text(f.name,Modifier.weight(1f),style=MaterialTheme.typography.bodySmall)
                TextButton(onClick={scope.launch{status="Loading ${f.name}…";try{
                    loadedModel?.unload()
                    loadedModel = null
                    val m=LocalModel(applicationContext)
                    try {
                        withContext(Dispatchers.IO){m.load(f)}
                        m.system("You are Nova, a careful offline AI. Separate facts, hypotheses and uncertainty.")
                        loadedModel=m
                    } catch (t: Throwable) {
                        runCatching { m.unload() }
                        throw t
                    }
                    getSharedPreferences("nova",MODE_PRIVATE).edit().putString("active_model_path",f.absolutePath).apply()
                    active=f.absolutePath;status="Model loaded."
                }catch(t:Throwable){status="Load failed: ${t.message}"}}}){Text("Load")}
            }}}
        }
    }

    override fun onStop() {
        val modelToUnload = loadedModel
        loadedModel = null
        val generation = activeChatJob
        activeChatJob = null
        generation?.cancel()
        cleanupScope.launch {
            runCatching { generation?.join() }
            runCatching { modelToUnload?.unload() }
        }
        super.onStop()
    }

    private companion object {
        val cleanupScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    }

    @Composable private fun Vault() {
        var records by remember{mutableStateOf(emptyList<EvidenceRecord>())}
        var status by remember{mutableStateOf("Generated hypotheses are kept separate from imported source documents.") }
        LaunchedEffect(Unit){records=withContext(Dispatchers.IO){db.dao().evidence()}}
        Column(Modifier.fillMaxSize().padding(16.dp)){
            Text("EVIDENCE VAULT",style=MaterialTheme.typography.headlineSmall)
            Text(status,style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(vertical=8.dp))
            Button(onClick={
                // Export remains in app-specific files; copy it out with Android's file manager.
                val f=File(getExternalFilesDir(null),"Nova_Backup_${System.currentTimeMillis()}.json")
                lifecycleScope.launch(Dispatchers.IO){
                    val dao=db.dao()
                    val json=org.json.JSONObject().apply {
                        put("version",1)
                        put("messages",org.json.JSONArray(dao.messages().map{org.json.JSONObject().put("role",it.role).put("text",it.text).put("createdAt",it.createdAt)}))
                        put("knowledge",org.json.JSONArray(dao.knowledge().map{org.json.JSONObject().put("title",it.title).put("source",it.source).put("content",it.content).put("importedAt",it.importedAt)}))
                        put("tasks",org.json.JSONArray(dao.tasks().map{org.json.JSONObject().put("topic",it.topic).put("status",it.status).put("report",it.report)}))
                        put("evidence",org.json.JSONArray(dao.evidence().map{org.json.JSONObject().put("topic",it.topic).put("title",it.title).put("content",it.content).put("classification",it.classification).put("provenance",it.provenance).put("confidence",it.confidence)}))
                    }.toString(2)
                    f.writeText(json)
                    withContext(Dispatchers.Main){status="Backup saved to app files: ${f.name}. Copy it out before uninstalling."}
                }
            },modifier=Modifier.fillMaxWidth()){Text("Export JSON backup")}
            LazyColumn{items(records){r->Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){Column(Modifier.padding(10.dp)){
                Text(r.title,style=MaterialTheme.typography.titleSmall)
                Text("${r.classification} • ${r.confidence}",style=MaterialTheme.typography.labelSmall)
                Text(r.provenance,style=MaterialTheme.typography.bodySmall)
                Text(r.content)
            }}}}
        }
    }
}
