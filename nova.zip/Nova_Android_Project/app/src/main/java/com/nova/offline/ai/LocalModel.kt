package com.nova.offline.ai

import android.content.Context
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.sync.Mutex
import java.io.File

/** App-owned adapter around the official llama.cpp Android binding. */
class LocalModel(context: Context) {
    private val engine: InferenceEngine = AiChat.getInferenceEngine(context.applicationContext)
    private var ownsSession = false

    suspend fun load(file: File) {
        require(file.isFile && file.extension.equals("gguf", true)) { "Select a valid GGUF model file." }
        check(!ownsSession) { "This Nova model session is already loaded. Unload it before loading another model." }
        inferenceLock.lock()
        try {
            // Recheck after acquiring the process-wide lock: another LocalModel
            // instance may have loaded while this instance was waiting.
            check(!ownsSession) { "This Nova model session is already loaded. Unload it before loading another model." }
            engine.loadModel(file.absolutePath)
            ownsSession = true
        } catch (t: Throwable) {
            // Native loading can fail after partial initialization. Best-effort cleanup
            // before releasing the process-wide lock so another session is not blocked.
            runCatching { engine.cleanUp() }
            inferenceLock.unlock()
            throw t
        }
    }

    suspend fun system(prompt: String) {
        check(ownsSession) { "Load a model before setting its system prompt." }
        engine.setSystemPrompt(prompt)
    }

    suspend fun generate(prompt: String, maxTokens: Int = 700): String {
        check(ownsSession) { "Load a model before generating a response." }
        require(prompt.isNotBlank()) { "Prompt cannot be empty." }
        val out = StringBuilder()
        engine.sendUserPrompt(prompt, maxTokens).collect { out.append(it) }
        return out.toString()
    }

    suspend fun unload() {
        if (!ownsSession) return
        try {
            engine.cleanUp()
        } finally {
            ownsSession = false
            inferenceLock.unlock()
        }
    }

    companion object {
        // The native binding exposes one process-wide engine. Serialize all model sessions.
        private val inferenceLock = Mutex()
    }
}
