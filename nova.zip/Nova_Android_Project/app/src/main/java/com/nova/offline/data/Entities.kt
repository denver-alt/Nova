package com.nova.offline.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class ChatMessage(@PrimaryKey(autoGenerate = true) val id: Long = 0, val role: String, val text: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "knowledge")
data class KnowledgeItem(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val source: String, val content: String, val importedAt: Long = System.currentTimeMillis())

@Entity(tableName = "study_tasks")
data class StudyTask(@PrimaryKey(autoGenerate = true) val id: Long = 0, val topic: String, val status: String = "QUEUED", val createdAt: Long = System.currentTimeMillis(), val updatedAt: Long = System.currentTimeMillis(), val report: String = "")

@Entity(tableName = "evidence")
data class EvidenceRecord(@PrimaryKey(autoGenerate = true) val id: Long = 0, val topic: String, val title: String, val content: String, val classification: String = "AI_GENERATED_HYPOTHESIS", val provenance: String, val confidence: String = "UNASSESSED", val createdAt: Long = System.currentTimeMillis())
