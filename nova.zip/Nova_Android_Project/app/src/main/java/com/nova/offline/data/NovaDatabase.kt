package com.nova.offline.data

import android.content.Context
import androidx.room.*

@Dao
interface NovaDao {
    @Insert suspend fun addMessage(x: ChatMessage): Long
    @Query("SELECT * FROM messages ORDER BY createdAt, id") suspend fun messages(): List<ChatMessage>
    @Insert suspend fun addKnowledge(x: KnowledgeItem): Long
    @Query("SELECT * FROM knowledge ORDER BY importedAt DESC") suspend fun knowledge(): List<KnowledgeItem>
    @Query("SELECT * FROM knowledge WHERE lower(title) LIKE '%' || lower(:q) || '%' OR lower(content) LIKE '%' || lower(:q) || '%' ORDER BY importedAt DESC LIMIT :limit")
    suspend fun searchKnowledge(q: String, limit: Int = 8): List<KnowledgeItem>
    @Insert suspend fun addTask(x: StudyTask): Long
    @Query("SELECT * FROM study_tasks ORDER BY createdAt DESC") suspend fun tasks(): List<StudyTask>
    @Query("SELECT * FROM study_tasks WHERE id=:id LIMIT 1") suspend fun task(id: Long): StudyTask?
    @Update suspend fun updateTask(x: StudyTask)
    @Insert suspend fun addEvidence(x: EvidenceRecord): Long
    @Query("SELECT * FROM evidence ORDER BY createdAt DESC") suspend fun evidence(): List<EvidenceRecord>
}

@Database(entities=[ChatMessage::class, KnowledgeItem::class, StudyTask::class, EvidenceRecord::class], version=1, exportSchema=false)
abstract class NovaDatabase : RoomDatabase() {
    abstract fun dao(): NovaDao
    companion object {
        @Volatile private var INSTANCE: NovaDatabase? = null
        fun get(c: Context): NovaDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(c.applicationContext, NovaDatabase::class.java, "nova_memory.db").build().also { INSTANCE=it }
        }
    }
}
