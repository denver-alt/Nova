package com.nova.offline.hf

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class HfModel(val id: String, val downloads: Long, val likes: Long)
data class HfFile(val name: String, val size: Long?)

class HuggingFaceClient {
    private val http = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(0, TimeUnit.SECONDS).build()

    fun search(query: String): List<HfModel> {
        val q = URLEncoder.encode(query, "UTF-8")
        val req = Request.Builder().url("https://huggingface.co/api/models?search=$q&filter=gguf&limit=25&sort=downloads&direction=-1").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Hugging Face HTTP ${r.code}")
            val a = JSONArray(r.body!!.string())
            return (0 until a.length()).map { i -> a.getJSONObject(i).let { HfModel(it.optString("id"), it.optLong("downloads"), it.optLong("likes")) } }
        }
    }

    fun files(repo: String): List<HfFile> {
        val req = Request.Builder().url("https://huggingface.co/api/models/$repo/tree/main?recursive=true&expand=true").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Repository file listing HTTP ${r.code}")
            val a = JSONArray(r.body!!.string())
            return (0 until a.length()).mapNotNull { i ->
                val o = a.getJSONObject(i); val name=o.optString("path")
                if (name.endsWith(".gguf", true)) HfFile(name, o.optJSONObject("lfs")?.optLong("size")) else null
            }
        }
    }

    fun download(repo: String, name: String, dest: File, progress: (Long,Long)->Unit) {
        dest.parentFile?.mkdirs()
        val encoded = name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+","%20") }
        val req = Request.Builder().url("https://huggingface.co/$repo/resolve/main/$encoded").header("User-Agent","NovaOfflineAI/0.1").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Download HTTP ${r.code}. Gated models require authentication, not included yet.")
            val total=r.body?.contentLength() ?: -1L
            val tmp=File(dest.parentFile, dest.name+".part")
            r.body!!.byteStream().use { input ->
                FileOutputStream(tmp).use { output ->
                    val buf=ByteArray(1024*1024); var done=0L
                    while (true) {
                        val n=input.read(buf); if(n<0) break
                        output.write(buf,0,n); done+=n; progress(done,total)
                    }
                    output.fd.sync()
                }
            }
            if (!tmp.renameTo(dest)) { tmp.copyTo(dest,true); tmp.delete() }
        }
    }
}
