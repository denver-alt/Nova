package com.nova.offline.learning

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.nova.offline.ai.LocalModel
import com.nova.offline.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class StudyWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c,p) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val id=inputData.getLong("task_id",-1L)
        val dao=NovaDatabase.get(applicationContext).dao()
        val task=dao.task(id) ?: return@withContext Result.failure()
        val path=applicationContext.getSharedPreferences("nova",Context.MODE_PRIVATE).getString("active_model_path",null)
        if(path.isNullOrBlank() || !File(path).exists()) {
            dao.updateTask(task.copy(status="WAITING_FOR_MODEL",updatedAt=System.currentTimeMillis()))
            return@withContext Result.failure()
        }
        try {
            dao.updateTask(task.copy(status="STUDYING",updatedAt=System.currentTimeMillis()))
            val docs=dao.searchKnowledge(task.topic,12)
            val source=docs.joinToString("\n\n") { "SOURCE: ${it.title} (${it.source})\n${it.content.take(4500)}" }
            val prompt = listOf(
                "Study topic: ${task.topic}",
                "Work from the local source passages below and pretrained knowledge. Do not claim internet research or external verification.",
                "Separate source statements, inferences, hypotheses, contradictions, and unanswered questions.",
                "Never label generated output as verified fact.",
                "LOCAL MATERIAL:",
                source.ifBlank { "[No matching imported source material. Clearly identify reliance on pretrained knowledge.]" },
                "Write: (1) what sources say, (2) connections, (3) hypotheses, (4) uncertainty, (5) evidence needed next."
            ).joinToString("\n\n")
            val model=LocalModel(applicationContext)
            val report = try {
                model.load(File(path))
                model.system("You are Nova, a careful offline research assistant. Preserve provenance and uncertainty.")
                model.generate(prompt,900)
            } finally {
                model.unload()
            }
            dao.addEvidence(EvidenceRecord(
                topic=task.topic, title="Study session: ${task.topic}", content=report,
                classification="AI_GENERATED_HYPOTHESIS",
                provenance="Generated offline using ${docs.size} matching local knowledge item(s) and pretrained model knowledge. No external verification performed.",
                confidence="UNASSESSED"
            ))
            dao.updateTask(task.copy(status="COMPLETED",updatedAt=System.currentTimeMillis(),report=report))
            Result.success()
        } catch(t:Throwable) {
            dao.updateTask(task.copy(status="ERROR: ${t.message}",updatedAt=System.currentTimeMillis()))
            Result.failure()
        }
    }
}
