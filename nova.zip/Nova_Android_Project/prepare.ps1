$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
New-Item -ItemType Directory -Force -Path "vendor" | Out-Null
if (-not (Test-Path "vendor/llama.cpp/.git")) {
    if (Test-Path "vendor/llama.cpp") { Remove-Item -Recurse -Force "vendor/llama.cpp" }
    git clone --depth 1 https://github.com/ggml-org/llama.cpp.git vendor/llama.cpp
    if ($LASTEXITCODE -ne 0) { throw "git clone failed" }
}
$module = Join-Path $PSScriptRoot "vendor/llama.cpp/examples/llama.android/lib"
$build = Join-Path $module "build.gradle.kts"
$cmake = Join-Path $module "src/main/cpp/CMakeLists.txt"
if (-not (Test-Path $build)) { throw "Official llama.cpp Android binding module not found" }
if (-not (Test-Path $cmake)) { throw "Native CMake project not found" }
$s = Get-Content -Raw $build
$s = [regex]::Replace($s, 'plugins\s*\{.*?\}', "plugins {`n    id(`"com.android.library`")`n    id(`"org.jetbrains.kotlin.android`")`n}", [System.Text.RegularExpressions.RegexOptions]::Singleline)
$s = $s.Replace('listOf("arm64-v8a", "x86_64")', 'listOf("arm64-v8a")')
$s = $s.Replace('implementation(libs.androidx.core.ktx)', 'implementation("androidx.core:core-ktx:1.17.0")')
$s = $s.Replace('implementation(libs.androidx.datastore.preferences)', 'implementation("androidx.datastore:datastore-preferences:1.2.0")')
$s = $s.Replace('testImplementation(libs.junit)', 'testImplementation("junit:junit:4.13.2")')
$s = $s.Replace('androidTestImplementation(libs.androidx.junit)', 'androidTestImplementation("androidx.test.ext:junit:1.3.0")')
if ($s -match '\blibs\.[A-Za-z0-9_.]+') { throw "Unconverted Gradle version-catalog aliases remain. Inspect upstream build.gradle.kts before proceeding." }
[System.IO.File]::WriteAllText($build, $s, [System.Text.UTF8Encoding]::new($false))
$aiCpp = Join-Path $module "src/main/cpp/ai_chat.cpp"
$native = Get-Content -Raw $aiCpp
$oldContext = "constexpr int DEFAULT_CONTEXT_SIZE = 8192;"
if (-not $native.Contains($oldContext)) { throw "Could not locate upstream context-size default; refusing to apply an uncertain patch" }
$native = $native.Replace($oldContext, "constexpr int DEFAULT_CONTEXT_SIZE = 4096;")
[System.IO.File]::WriteAllText($aiCpp, $native, [System.Text.UTF8Encoding]::new($false))
Write-Host "llama.cpp source and Android binding prepared in vendor/llama.cpp."
Write-Host "Nova uses a 4096-token default context to reduce memory pressure on the OnePlus 9."
Write-Host "Open this project in Android Studio and build the app module."
