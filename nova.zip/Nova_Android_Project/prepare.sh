#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p vendor
if [ ! -d vendor/llama.cpp/.git ]; then
  rm -rf vendor/llama.cpp
  git clone --depth 1 https://github.com/ggml-org/llama.cpp.git vendor/llama.cpp
fi
MODULE="vendor/llama.cpp/examples/llama.android/lib"
BUILD="$MODULE/build.gradle.kts"
CPP="$MODULE/src/main/cpp/CMakeLists.txt"
test -f "$BUILD" || { echo "Official llama.cpp Android binding module not found"; exit 1; }
test -f "$CPP" || { echo "Native CMake project not found"; exit 1; }
python3 - "$BUILD" <<'PY'
from pathlib import Path
import re, sys
p=Path(sys.argv[1]); s=p.read_text()
s=re.sub(r'plugins\s*\{.*?\}', 'plugins {\n    id("com.android.library")\n    id("org.jetbrains.kotlin.android")\n}', s, count=1, flags=re.S)
s=s.replace('listOf("arm64-v8a", "x86_64")', 'listOf("arm64-v8a")')
s=s.replace('implementation(libs.androidx.core.ktx)', 'implementation("androidx.core:core-ktx:1.17.0")')
s=s.replace('implementation(libs.androidx.datastore.preferences)', 'implementation("androidx.datastore:datastore-preferences:1.2.0")')
s=s.replace('testImplementation(libs.junit)', 'testImplementation("junit:junit:4.13.2")')
s=s.replace('androidTestImplementation(libs.androidx.junit)', 'androidTestImplementation("androidx.test.ext:junit:1.3.0")')
leftovers = re.findall(r'\blibs\.[A-Za-z0-9_.]+', s)
if leftovers:
    raise SystemExit('Unconverted Gradle version-catalog aliases remain: ' + ', '.join(sorted(set(leftovers))))
p.write_text(s)
PY
AI_CPP="vendor/llama.cpp/examples/llama.android/lib/src/main/cpp/ai_chat.cpp"
python3 - "$AI_CPP" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
old="constexpr int DEFAULT_CONTEXT_SIZE = 8192;"
if old not in s:
    raise SystemExit("Upstream llama.cpp changed its context-size declaration. No patch was applied; inspect ai_chat.cpp before proceeding.")
p.write_text(s.replace(old, "constexpr int DEFAULT_CONTEXT_SIZE = 4096;", 1))
PY
echo "llama.cpp source and Android binding prepared in vendor/llama.cpp."
echo "Nova uses a 4096-token default context to reduce memory pressure on the OnePlus 9."
echo "Open this project in Android Studio and build the app module."
