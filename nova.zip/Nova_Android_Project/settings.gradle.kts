pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "NovaOfflineAI"
include(":app")
val llamaAndroidModule = file("vendor/llama.cpp/examples/llama.android/lib")
if (llamaAndroidModule.resolve("build.gradle.kts").exists()) {
    include(":llama-android-lib")
    project(":llama-android-lib").projectDir = llamaAndroidModule
}
